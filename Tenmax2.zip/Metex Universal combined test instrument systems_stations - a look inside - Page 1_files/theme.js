function smf_codeBoxFix()
{var codeFix=document.getElementsByTagName('code');for(var i=codeFix.length- 1;i>=0;i--)
{if(is_webkit&&codeFix[i].offsetHeight<20)
codeFix[i].style.height=(codeFix[i].offsetHeight+ 20)+'px';else if(is_ff&&(codeFix[i].scrollWidth>codeFix[i].clientWidth||codeFix[i].clientWidth==0))
codeFix[i].style.overflow='scroll';else if('currentStyle'in codeFix[i]&&codeFix[i].currentStyle.overflow=='auto'&&(codeFix[i].currentStyle.height==''||codeFix[i].currentStyle.height=='auto')&&(codeFix[i].scrollWidth>codeFix[i].clientWidth||codeFix[i].clientWidth==0)&&(codeFix[i].offsetHeight!=0))
codeFix[i].style.height=(codeFix[i].offsetHeight+ 24)+'px';}}
if((is_ie&&!is_ie4)||is_webkit||is_ff)
addLoadEvent(smf_codeBoxFix);function smc_toggleImageDimensions()
{var oImages=document.getElementsByTagName('IMG');for(oImage in oImages)
{if(oImages[oImage].className==undefined||oImages[oImage].className.indexOf('bbc_img resized')==-1)
continue;oImages[oImage].style.cursor='pointer';oImages[oImage].onclick=function(){this.style.width=this.style.height=this.style.width=='auto'?null:'auto';};}}
addLoadEvent(smc_toggleImageDimensions);function smf_addButton(sButtonStripId,bUseImage,oOptions)
{var oButtonStrip=document.getElementById(sButtonStripId);var aItems=oButtonStrip.getElementsByTagName('span');if(aItems.length>0)
{var oLastSpan=aItems[aItems.length- 1];oLastSpan.className=oLastSpan.className.replace(/\s*last/,'position_holder');}
var oButtonStripList=oButtonStrip.getElementsByTagName('ul')[0];var oNewButton=document.createElement('li');setInnerHTML(oNewButton,'<a href="'+ oOptions.sUrl+'" '+('sCustom'in oOptions?oOptions.sCustom:'')+'><span class="last"'+('sId'in oOptions?' id="'+ oOptions.sId+'"':'')+'>'+ oOptions.sText+'</span></a>');oButtonStripList.appendChild(oNewButton);}
var smf_addListItemHoverEvents=function()
{var cssRule,newSelector;for(var iStyleSheet=0;iStyleSheet<document.styleSheets.length;iStyleSheet++)
for(var iRule=0;iRule<document.styleSheets[iStyleSheet].rules.length;iRule++)
{oCssRule=document.styleSheets[iStyleSheet].rules[iRule];if(oCssRule.selectorText.indexOf('LI:hover')!=-1)
{sNewSelector=oCssRule.selectorText.replace(/LI:hover/gi,'LI.iehover');document.styleSheets[iStyleSheet].addRule(sNewSelector,oCssRule.style.cssText);}}
var oListItems=document.getElementsByTagName('LI');for(oListItem in oListItems)
{oListItems[oListItem].onmouseover=function(){this.className+=' iehover';};oListItems[oListItem].onmouseout=function(){this.className=this.className.replace(new RegExp(' iehover\\b'),'');};}}
if(is_ie7down&&'attachEvent'in window)
window.attachEvent('onload',smf_addListItemHoverEvents);